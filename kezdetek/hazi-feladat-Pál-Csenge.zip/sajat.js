console.log("1. feladat: ");
a = 15;
b = 12;
c = a + b;

console.log(a);
console.log(b);
console.log(c);

console.log("2. feladat: ");

const lista = [0, 7, 16, 30, 41]
console.log(lista);